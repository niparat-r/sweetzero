import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeFoodImage = async (base64Image: string): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image
            }
          },
          {
            text: "Analyze this food image. Estimate the food name, sugar content in grams, total calories, and classify the sugar level (LOW, MEDIUM, HIGH). Also provide a very short, one-sentence advice about consuming this item."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            foodName: { type: Type.STRING },
            sugarGrams: { type: Type.NUMBER },
            calories: { type: Type.NUMBER },
            sugarLevel: { type: Type.STRING, enum: ["LOW", "MEDIUM", "HIGH"] },
            advice: { type: Type.STRING }
          },
          required: ["foodName", "sugarGrams", "calories", "sugarLevel", "advice"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as AnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};
