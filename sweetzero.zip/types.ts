export interface UserProfile {
  name: string;
  age: number;
  weight: number; // kg
  height: number; // cm
  dailySugarTarget: number; // grams
  xp: number;
  level: number;
  coins: number;
}

export interface FoodLog {
  id: string;
  foodName: string;
  sugarGrams: number;
  calories: number;
  sugarLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  timestamp: number;
  advice?: string;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  coinReward: number;
  isCompleted: boolean;
  type: 'daily' | 'one-time';
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  score: number;
  rank: number;
  avatarColor: string;
}

export interface AnalysisResult {
  foodName: string;
  sugarGrams: number;
  calories: number;
  sugarLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  advice: string;
}
