import React from 'react';
import { Smile, Meh, Frown } from 'lucide-react';

interface AvatarProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
}

export const Avatar: React.FC<AvatarProps> = ({ score, size = 'md' }) => {
  let Color = "bg-[#4CC9F0]"; // Blue (Good)
  let Icon = Smile;

  if (score < 50) {
    Color = "bg-[#FF6B6B]"; // Red (Bad)
    Icon = Frown;
  } else if (score < 80) {
    Color = "bg-yellow-400"; // Yellow (Warning)
    Icon = Meh;
  } else {
    Color = "bg-[#90BE6D]"; // Green (Great - using Green for high score context usually, but prompted blue as primary. Let's stick to score logic)
  }

  const sizeClasses = {
    sm: "w-10 h-10",
    md: "w-16 h-16",
    lg: "w-24 h-24"
  };

  const iconSizes = {
    sm: 20,
    md: 32,
    lg: 48
  };

  return (
    <div className={`${sizeClasses[size]} ${Color} rounded-full flex items-center justify-center text-white shadow-lg transition-all duration-500`}>
      <Icon size={iconSizes[size]} />
    </div>
  );
};
